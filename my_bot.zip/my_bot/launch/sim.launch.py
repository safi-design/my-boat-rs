"""Launch Gazebo Harmonic with the robot spawned, ros_gz bridge, and RViz2."""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    pkg = get_package_share_directory('my_bot')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')

    xacro_file = os.path.join(pkg, 'urdf', 'my_bot.urdf.xacro')

    world_arg = DeclareLaunchArgument(
        'world', default_value='empty.sdf',
        description='World file in my_bot/worlds (e.g. bump_test.sdf)')

    rviz_arg = DeclareLaunchArgument(
        'rviz_config', default_value='view.rviz',
        description='RViz config in my_bot/rviz (view.rviz or slam.rviz)')
    rviz_config_file = PathJoinSubstitution([FindPackageShare('my_bot'), 'rviz',
                                             LaunchConfiguration('rviz_config')])
    world_file = PathJoinSubstitution([FindPackageShare('my_bot'), 'worlds',
                                       LaunchConfiguration('world')])

    robot_description = ParameterValue(
        Command(['xacro ', xacro_file]), value_type=str)

    # Gazebo Harmonic (gz sim)
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')),
        launch_arguments={'gz_args': ['-r ', world_file]}.items(),
    )

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': robot_description,
                     'use_sim_time': True}],
    )

    # Spawn robot from /robot_description topic
    spawn = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=['-topic', 'robot_description',
                   '-name', 'my_bot',
                   '-z', '0.05'],
        output='screen',
    )

    # Bridge Gazebo <-> ROS 2 topics
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/cmd_vel@geometry_msgs/msg/Twist]gz.msgs.Twist',
            '/drill_cmd@std_msgs/msg/Float64]gz.msgs.Double',
            '/plow_cmd@std_msgs/msg/Float64]gz.msgs.Double',
            '/gimbal_pan_cmd@std_msgs/msg/Float64]gz.msgs.Double',
            '/gimbal_tilt_cmd@std_msgs/msg/Float64]gz.msgs.Double',
            '/laser_cam/image@sensor_msgs/msg/Image[gz.msgs.Image',
            '/front_cam/image@sensor_msgs/msg/Image[gz.msgs.Image',
            '/front_cam/depth_image@sensor_msgs/msg/Image[gz.msgs.Image',
            '/front_cam/camera_info@sensor_msgs/msg/CameraInfo[gz.msgs.CameraInfo',
            '/front_cam/points@sensor_msgs/msg/PointCloud2[gz.msgs.PointCloudPacked',
            '/front_down_cam/image@sensor_msgs/msg/Image[gz.msgs.Image',
            '/gimbal_watch_cam/image@sensor_msgs/msg/Image[gz.msgs.Image',
            '/imu@sensor_msgs/msg/Imu[gz.msgs.IMU',
            '/odom@nav_msgs/msg/Odometry[gz.msgs.Odometry',
            '/joint_states@sensor_msgs/msg/JointState[gz.msgs.Model',
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
        ],
        parameters=[{'use_sim_time': True}],
        output='screen',
    )

    # EKF sensor fusion: /odom + /imu -> /odometry/filtered + odom->base_footprint TF
    ekf = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node',
        parameters=[os.path.join(pkg, 'config', 'ekf.yaml')],
        output='screen',
    )

    rviz = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_config_file],
        parameters=[{'use_sim_time': True}],
    )

    return LaunchDescription([
        world_arg,
        rviz_arg,
        gazebo,
        robot_state_publisher,
        spawn,
        bridge,
        ekf,
        rviz,
    ])
