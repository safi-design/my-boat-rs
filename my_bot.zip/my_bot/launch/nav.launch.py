"""EVERYTHING in one launch: sim + SLAM + Nav2 + costmap voxel markers.

Usage:
    ros2 launch my_bot nav.launch.py
    ros2 launch my_bot nav.launch.py world:=bump_test.sdf

Startup sequencing (per Nav2 docs: sim first, SLAM second, Nav2 third):
  t=0s   Gazebo + robot + bridge + EKF + RViz
  t=8s   depth->scan + slam_toolbox        (wait for "Registering sensor")
  t=20s  Nav2 navigation servers           (wait for "Creating bond timer")
  t=25s  voxel grid marker publisher
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription,
                            TimerAction)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg = get_package_share_directory('my_bot')
    nav2_bringup_dir = get_package_share_directory('nav2_bringup')

    world_arg = DeclareLaunchArgument(
        'world', default_value='arena.sdf',
        description='World file in my_bot/worlds')
    rviz_arg = DeclareLaunchArgument(
        'rviz_config', default_value='nav.rviz',
        description='RViz config in my_bot/rviz')

    # sim + SLAM (bringup already sequences SLAM at t=8s)
    bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg, 'launch', 'bringup.launch.py')),
        launch_arguments={
            'world': LaunchConfiguration('world'),
            'rviz_config': LaunchConfiguration('rviz_config'),
            'slam': 'true',
        }.items(),
    )

    # Nav2 after SLAM has registered and map->odom TF exists
    nav2 = TimerAction(
        period=20.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(nav2_bringup_dir, 'launch',
                                 'navigation_launch.py')),
                launch_arguments={'use_sim_time': 'true'}.items(),
            ),
        ],
    )

    # voxel grid -> RViz markers (Nav2 docs visualization step)
    voxel_markers = TimerAction(
        period=25.0,
        actions=[
            Node(
                package='nav2_costmap_2d',
                executable='nav2_costmap_2d_markers',
                name='voxel_visualizer',
                remappings=[
                    ('voxel_grid', '/local_costmap/voxel_grid'),
                    ('visualization_marker', '/my_marker'),
                ],
                parameters=[{'use_sim_time': True}],
                output='screen',
            ),
        ],
    )

    return LaunchDescription([
        world_arg,
        rviz_arg,
        bringup,
        nav2,
        voxel_markers,
    ])
