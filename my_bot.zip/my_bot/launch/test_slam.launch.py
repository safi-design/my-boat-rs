"""ISOLATION TEST: depth->scan converter + STOCK slam_toolbox launch.

Uses slam_toolbox's own online_async_launch.py with its default config
(exactly as the Nav2 setup guide does) instead of our custom slam.yaml.
Purpose: determine whether the custom config is the reason no map appears.

Usage (with sim already running WITHOUT our slam):
    ros2 launch my_bot bringup.launch.py slam:=false
    ros2 launch my_bot test_slam.launch.py     # <- this file

Watch this terminal for slam_toolbox printing "Registering sensor".
  - appears + map in RViz  -> custom slam.yaml is the problem
  - never appears          -> scan/TF is being rejected; the printed
                              errors identify the real blocker
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def generate_launch_description():
    slam_toolbox_dir = get_package_share_directory('slam_toolbox')

    depth_to_scan = Node(
        package='depthimage_to_laserscan',
        executable='depthimage_to_laserscan_node',
        name='depthimage_to_laserscan',
        remappings=[
            ('depth', '/front_cam/depth_image'),
            ('depth_camera_info', '/front_cam/camera_info'),
            ('scan', '/scan'),
        ],
        parameters=[{
            'use_sim_time': True,
            'output_frame': 'front_cam',
            'range_min': 0.3,
            'range_max': 8.0,
            'scan_height': 10,
            'scan_time': 0.1,
        }],
        output='screen',
    )

    # STOCK slam_toolbox launch, default config - per Nav2 setup guide
    stock_slam = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(slam_toolbox_dir, 'launch', 'online_async_launch.py')),
        launch_arguments={'use_sim_time': 'true'}.items(),
    )

    return LaunchDescription([
        depth_to_scan,
        stock_slam,
    ])
