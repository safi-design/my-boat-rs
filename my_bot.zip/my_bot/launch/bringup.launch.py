"""ONE launch file for everything: Gazebo + robot + bridge + EKF + RViz + SLAM.

Usage:
    ros2 launch my_bot bringup.launch.py                       # arena + SLAM
    ros2 launch my_bot bringup.launch.py world:=bump_test.sdf  # other world
    ros2 launch my_bot bringup.launch.py slam:=false           # sim only

Then drive in another terminal:
    ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args -p stamped:=false
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription,
                            TimerAction)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    pkg = get_package_share_directory('my_bot')

    world_arg = DeclareLaunchArgument(
        'world', default_value='arena.sdf',
        description='World file in my_bot/worlds')
    rviz_arg = DeclareLaunchArgument(
        'rviz_config', default_value='slam.rviz',
        description='RViz config in my_bot/rviz')
    slam_arg = DeclareLaunchArgument(
        'slam', default_value='true',
        description='Start SLAM (depth->scan + slam_toolbox)')
    explore_arg = DeclareLaunchArgument(
        'explore', default_value='false',
        description='Robot wanders and maps by itself')

    sim = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg, 'launch', 'sim.launch.py')),
        launch_arguments={
            'world': LaunchConfiguration('world'),
            'rviz_config': LaunchConfiguration('rviz_config'),
        }.items(),
    )

    # start SLAM after the sim has had time to spawn the robot and
    # start publishing sensors/TF (avoids startup message-drop spam)
    slam = TimerAction(
        period=8.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg, 'launch', 'slam.launch.py')),
                condition=IfCondition(LaunchConfiguration('slam')),
            ),
        ],
    )

    from launch_ros.actions import Node
    explore = TimerAction(
        period=15.0,
        actions=[
            Node(
                package='my_bot',
                executable='auto_explore.py',
                name='auto_explore',
                output='screen',
                condition=IfCondition(LaunchConfiguration('explore')),
            ),
        ],
    )

    return LaunchDescription([
        world_arg,
        rviz_arg,
        slam_arg,
        explore_arg,
        sim,
        slam,
        explore,
    ])
