"""SLAM from the front RGB-D camera.

Run standalone after sim, or automatically via bringup.launch.py:
    ros2 launch my_bot slam.launch.py

Pipeline:
  /front_cam/depth_image + camera_info
      -> depthimage_to_laserscan -> /scan
      -> slam_toolbox (STOCK online_async launch + our params) -> /map + map->odom TF
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def generate_launch_description():
    pkg = get_package_share_directory('my_bot')
    slam_toolbox_dir = get_package_share_directory('slam_toolbox')
    slam_params = os.path.join(pkg, 'config', 'slam.yaml')

    depth_to_scan = Node(
        package='depthimage_to_laserscan',
        executable='depthimage_to_laserscan_node',
        name='depthimage_to_laserscan',
        remappings=[
            ('depth', '/front_cam/depth_image'),
            ('depth_camera_info', '/front_cam/camera_info'),
            ('scan', '/scan'),
        ],
        parameters=[{
            'use_sim_time': True,
            'output_frame': 'front_cam',
            'range_min': 0.3,
            'range_max': 8.0,
            'scan_height': 10,
            'scan_time': 0.1,
        }],
        output='screen',
    )

    # STOCK slam_toolbox launch (proven working), with our params file
    slam = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(slam_toolbox_dir, 'launch', 'online_async_launch.py')),
        launch_arguments={
            'use_sim_time': 'true',
            'slam_params_file': slam_params,
        }.items(),
    )

    return LaunchDescription([
        depth_to_scan,
        slam,
    ])
