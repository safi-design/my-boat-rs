#!/usr/bin/env bash
# ============================================================
# my_bot debug reporter
# Run while the simulation is up:  bash debug_report.sh
# Collects environment, Gazebo, ROS 2, bridge, TF and camera
# status into a single report: ~/my_bot_debug_report.txt
# ============================================================

REPORT=~/my_bot_debug_report.txt
: > "$REPORT"

log()    { echo -e "$1" | tee -a "$REPORT"; }
header() { log "\n============================================================"; log "== $1"; log "============================================================"; }
run()    { log "\n\$ $1"; timeout 10 bash -c "$1" 2>&1 | tee -a "$REPORT"; }

log "my_bot debug report - $(date)"
log "host: $(hostname)  user: $(whoami)"

# ------------------------------------------------------------
header "1. ENVIRONMENT"
run "echo ROS_DISTRO=\$ROS_DISTRO"
run "echo LIBGL_ALWAYS_SOFTWARE=\$LIBGL_ALWAYS_SOFTWARE"
run "echo GZ_SIM_RESOURCE_PATH=\$GZ_SIM_RESOURCE_PATH"
run "gz sim --version"
run "echo RMW_IMPLEMENTATION=\$RMW_IMPLEMENTATION"
if [ "$RMW_IMPLEMENTATION" != "rmw_cyclonedds_cpp" ]; then
  log "  [WARNING] Using default FastDDS middleware."
  log "     On WSL this causes 'RTPS_TRANSPORT_SHM' errors, lost messages,"
  log "     starved image/TF rates, and SLAM failing to build a map."
  log "     FIX: sudo apt install ros-\$ROS_DISTRO-rmw-cyclonedds-cpp"
  log "          echo 'export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp' >> ~/.bashrc"
  log "          then restart ALL terminals and relaunch everything."
fi
run "echo CYCLONEDDS_URI=\$CYCLONEDDS_URI"
if [ "$RMW_IMPLEMENTATION" = "rmw_cyclonedds_cpp" ] && [ -z "$CYCLONEDDS_URI" ]; then
  log "  [WARNING] CycloneDDS without a config: default ~10 node limit per host."
  log "     Nav2 alone adds 11 nodes -> 'Failed to find a free participant index'."
  log "     FIX: export CYCLONEDDS_URI=file://\$HOME/ros2_ws/src/my_bot/config/cyclonedds.xml"
fi
log "\n-- /clock check (sim time must flow for use_sim_time nodes) --"
timeout 5 ros2 topic hz /clock 2>&1 | tail -1 | tee -a "$REPORT"
run "uname -a"
grep -qi microsoft /proc/version && log ">> Running inside WSL" || log ">> Not WSL"

# ------------------------------------------------------------
header "2. GRAPHICS / RENDERING"
run "glxinfo -B 2>/dev/null | head -15 || echo 'glxinfo not installed (sudo apt install mesa-utils)'"

# ------------------------------------------------------------
header "3. PROCESSES"
run "pgrep -a -f 'gz sim' | head -5"
NSERV=$(pgrep -f "gz sim server" | wc -l)
if [ "$NSERV" -gt 1 ]; then
  log "  [WARNING] $NSERV Gazebo servers running! Zombie sims are eating CPU and starving topic rates."
  log "  FIX: pkill -9 -f 'gz sim'  then relaunch."
else
  log "  [OK] single Gazebo server"
fi
run "pgrep -a -f 'parameter_bridge' | head -3"
run "pgrep -a -f 'robot_state_publisher' | head -3"
run "pgrep -a -f 'rviz2' | head -3"

# ------------------------------------------------------------
header "4. GAZEBO TOPICS"
run "gz topic -l"

log "\n-- checking gz camera topics --"
for t in /laser_cam/image /front_cam/image /front_down_cam/image /gimbal_watch_cam/image; do
  if gz topic -l 2>/dev/null | grep -qx "$t"; then
    log "  [OK]      gz topic exists: $t"
  else
    log "  [MISSING] gz topic: $t"
  fi
done

log "\n-- gz camera frame check (3 s each) --"
for t in /front_cam/image; do
  if gz topic -l 2>/dev/null | grep -qx "$t"; then
    N=$(timeout 3 gz topic -e -t "$t" 2>/dev/null | grep -c "^header" )
    log "  $t : $N frames in 3 s $( [ "$N" -eq 0 ] && echo '<-- SENSOR NOT RENDERING (render engine problem)' )"
  fi
done

# ------------------------------------------------------------
header "5. ROS 2 TOPICS"
run "ros2 topic list"

log "\n-- checking ROS camera topics --"
for t in /laser_cam/image /front_cam/image /front_cam/depth_image /front_cam/points /front_down_cam/image /gimbal_watch_cam/image; do
  if ros2 topic list 2>/dev/null | grep -qx "$t"; then
    log "  [OK]      ros topic exists: $t"
  else
    log "  [MISSING] ros topic: $t  <-- bridge not creating it"
  fi
done

log "\n-- ROS topic rates (5 s each) --"
for t in /front_cam/image /odom /joint_states /imu; do
  log "  rate of $t:"
  timeout 5 ros2 topic hz "$t" 2>&1 | tail -2 | tee -a "$REPORT"
done

# ------------------------------------------------------------
header "6. CONTROL SANITY"
log "-- gz joint/actuator command topics --"
for t in /cmd_vel /drill_cmd /plow_cmd /gimbal_pan_cmd /gimbal_tilt_cmd; do
  gz topic -l 2>/dev/null | grep -qx "$t" && log "  [OK]      gz $t" || log "  [MISSING] gz $t"
done

# ------------------------------------------------------------
header "7. TF TREE"
run "ros2 run tf2_ros tf2_echo odom base_footprint 2>&1 | head -6"

# ------------------------------------------------------------
header "8. JOINT STATES"
run "ros2 topic echo /joint_states --once --field name"

# ------------------------------------------------------------
header "9. DEPTH CAMERA (RGB-D) DEEP CHECK"

log "-- gz side: do depth topics exist? --"
for t in /front_cam/depth_image /front_cam/points /front_cam/camera_info; do
  gz topic -l 2>/dev/null | grep -qx "$t" && log "  [OK]      gz $t" || log "  [MISSING] gz $t"
done

log "\n-- gz side: are depth FRAMES being produced? (3 s) --"
N=$(timeout 3 gz topic -e -t /front_cam/depth_image 2>/dev/null | grep -c "width")
log "  /front_cam/depth_image: $N frames in 3 s $( [ "$N" -eq 0 ] && echo '<-- DEPTH RENDERER NOT PRODUCING (ogre2/GL issue)' )"

log "\n-- ros side: do depth topics exist? --"
for t in /front_cam/depth_image /front_cam/points /front_cam/camera_info; do
  ros2 topic list 2>/dev/null | grep -qx "$t" && log "  [OK]      ros $t" || log "  [MISSING] ros $t  <-- bridge lacks this line"
done

log "\n-- STALE INSTALL CHECK: does the INSTALLED launch file bridge depth? --"
INST=$(ros2 pkg prefix my_bot 2>/dev/null)/share/my_bot/launch/sim.launch.py
if [ -f "$INST" ]; then
  if grep -q "depth_image" "$INST"; then
    log "  [OK] installed sim.launch.py contains depth bridge lines"
  else
    log "  [STALE] installed sim.launch.py has NO depth lines!"
    log "     -> your build did not pick up the new source."
    log "     FIX: cd ~/ros2_ws && rm -rf build install log && colcon build --packages-select my_bot && source install/setup.bash"
  fi
else
  log "  [ERROR] cannot find installed my_bot package (did you source install/setup.bash?)"
fi

log "\n-- ros side: depth rate (5 s) --"
timeout 5 ros2 topic hz /front_cam/depth_image 2>&1 | tail -2 | tee -a "$REPORT"

# ------------------------------------------------------------
header "10. SENSOR FUSION (EKF)"
run "pgrep -a -f ekf_node | head -3"
log "\n-- EKF topics --"
for t in /odometry/filtered; do
  ros2 topic list 2>/dev/null | grep -qx "$t" && log "  [OK]      $t" || log "  [MISSING] $t  <-- ekf_node not running (sudo apt install ros-\$ROS_DISTRO-robot-localization?)"
done
log "\n-- /odometry/filtered rate (5 s) --"
timeout 5 ros2 topic hz /odometry/filtered 2>&1 | tail -2 | tee -a "$REPORT"
log "\n-- TF odom->base_footprint (should come from ekf_filter_node ONLY) --"
timeout 5 ros2 run tf2_ros tf2_echo odom base_footprint 2>&1 | head -4 | tee -a "$REPORT"
log "\n-- checking for double TF publishers on odom->base_footprint --"
PUBS=$(timeout 3 ros2 topic echo /tf --once 2>/dev/null | grep -c "base_footprint")
log "  (if robot pose jitters/teleports in RViz, two nodes are fighting over this TF)"
log "\n-- EKF input health --"
for t in /odom /imu; do
  log "  rate of $t:"
  timeout 5 ros2 topic hz "$t" 2>&1 | tail -1 | tee -a "$REPORT"
done

# ------------------------------------------------------------
header "11. SLAM"

log "-- SLAM processes --"
pgrep -f slam_toolbox >/dev/null && log "  [OK]      slam_toolbox running" || log "  [MISSING] slam_toolbox NOT running  -> ros2 launch my_bot slam.launch.py"
pgrep -f depthimage_to_laserscan >/dev/null && log "  [OK]      depthimage_to_laserscan running" || log "  [MISSING] depthimage_to_laserscan NOT running (part of slam.launch.py)"

log "\n-- SLAM packages installed? --"
ros2 pkg prefix slam_toolbox >/dev/null 2>&1 && log "  [OK]      slam_toolbox installed" || log "  [MISSING] sudo apt install ros-\$ROS_DISTRO-slam-toolbox"
ros2 pkg prefix depthimage_to_laserscan >/dev/null 2>&1 && log "  [OK]      depthimage_to_laserscan installed" || log "  [MISSING] sudo apt install ros-\$ROS_DISTRO-depthimage-to-laserscan"

log "\n-- SLAM topics --"
for t in /scan /map; do
  ros2 topic list 2>/dev/null | grep -qx "$t" && log "  [OK]      $t" || log "  [MISSING] $t"
done

log "\n-- /scan rate (5 s) --"
timeout 5 ros2 topic hz /scan 2>&1 | tail -2 | tee -a "$REPORT"

log "\n-- /scan content: finite ranges vs inf --"
SCAN=$(timeout 5 ros2 topic echo /scan --once --field ranges 2>/dev/null)
NFIN=$(echo "$SCAN" | tr ',' '\n' | grep -cE "[0-9]\.[0-9]")
NINF=$(echo "$SCAN" | tr ',' '\n' | grep -c "inf")
log "  finite range values: $NFIN   inf values: $NINF"
if [ "$NFIN" -eq 0 ] && [ -n "$SCAN" ]; then
  log "  [PROBLEM] scan is ALL inf -> nothing at camera horizon height."
  log "     The scan slice is ~0.5 m above ground; low bumps are invisible."
  log "     Face the robot toward tall obstacles (ramp platform / walls)."
fi

log "\n-- scan frame check --"
SF=$(timeout 5 ros2 topic echo /scan --once --field header.frame_id 2>/dev/null | head -1)
log "  /scan frame_id: $SF (expected: front_cam)"

log "\n-- map->odom TF (slam_toolbox provides once first scan matched) --"
timeout 5 ros2 run tf2_ros tf2_echo map odom 2>&1 | head -4 | tee -a "$REPORT"

log "\n-- /map status --"
MW=$(timeout 5 ros2 topic echo /map --once --field info.width 2>/dev/null | head -1)
if [ -n "$MW" ]; then
  MH=$(timeout 5 ros2 topic echo /map --once --field info.height 2>/dev/null | head -1)
  log "  [OK] map exists: ${MW}x${MH} cells"
else
  log "  [PROBLEM] no map message yet."
  log "     slam_toolbox publishes map only after receiving valid scans + TF."
  log "     Check: /scan has finite ranges, and odom->base_footprint TF is alive (section 10)."
fi

log "\n-- full TF chain for SLAM: map -> odom -> base_footprint -> front_cam --"
timeout 5 ros2 run tf2_ros tf2_echo map front_cam 2>&1 | head -3 | tee -a "$REPORT"

# ------------------------------------------------------------
header "12. VERDICT"
GZCAM=$(gz topic -l 2>/dev/null | grep -c "cam/image")
ROSCAM=$(ros2 topic list 2>/dev/null | grep -c "cam/image")
if [ "$GZCAM" -eq 0 ]; then
  log "DIAGNOSIS: Camera sensors were never created or are not rendering."
  log "  Most likely: render engine failure (ogre2 on WSL/software GL)."
  log "  FIX: in both world files change <render_engine>ogre2</render_engine>"
  log "       to <render_engine>ogre</render_engine>, rebuild, relaunch."
  log "  Also ensure: export LIBGL_ALWAYS_SOFTWARE=1 before launching."
elif [ "$ROSCAM" -eq 0 ]; then
  log "DIAGNOSIS: Gazebo has camera topics but ROS does not."
  log "  The bridge topic names do not match. Compare section 4 vs 5 names."
else
  log "DIAGNOSIS: Camera topics exist on both sides."
  log "  If images are still blank, check frame counts in section 4;"
  log "  0 frames = renderer problem, >0 frames = viewer problem."
fi

log "\nReport saved to: $REPORT"
log "Send this file back for analysis."
