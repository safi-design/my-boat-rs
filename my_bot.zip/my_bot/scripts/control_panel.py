#!/usr/bin/env python3
"""GUI control panel for my_bot.

One window controlling:
  - Driving (Ackermann teleop): buttons + WASD/arrow keys + speed slider
  - Drill linear actuator: slider 0..0.24 m + presets
  - Soil leveler: slider (raised +0.4 .. lowered -0.6 rad) + presets
  - Laser gimbal: pan and tilt sliders + center button

Run (with the sim up):
    ros2 run my_bot control_panel.py
"""
import threading
import tkinter as tk
from tkinter import ttk

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64


class RosBackend(Node):
    def __init__(self):
        super().__init__('control_panel')
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.drill_pub = self.create_publisher(Float64, '/drill_cmd', 10)
        self.plow_pub = self.create_publisher(Float64, '/plow_cmd', 10)
        self.pan_pub = self.create_publisher(Float64, '/gimbal_pan_cmd', 10)
        self.tilt_pub = self.create_publisher(Float64, '/gimbal_tilt_cmd', 10)

        self.lin = 0.0
        self.ang = 0.0
        # publish drive command continuously so the plugin keeps moving
        self.create_timer(0.1, self._drive_tick)

    def _drive_tick(self):
        t = Twist()
        t.linear.x = self.lin
        t.angular.z = self.ang
        self.cmd_pub.publish(t)

    def send(self, pub, value):
        m = Float64()
        m.data = float(value)
        pub.publish(m)


class ControlPanel:
    def __init__(self, ros: RosBackend):
        self.ros = ros
        self.root = tk.Tk()
        self.root.title('my_bot control panel')
        self.root.geometry('460x640')

        pad = {'padx': 8, 'pady': 4}

        # ================= DRIVE =================
        drive = ttk.LabelFrame(self.root, text='Drive  (WASD / arrows, Space = stop)')
        drive.pack(fill='x', **pad)

        self.speed_var = tk.DoubleVar(value=0.6)
        ttk.Label(drive, text='Speed (m/s)').grid(row=0, column=0, sticky='w')
        ttk.Scale(drive, from_=0.1, to=2.0, variable=self.speed_var,
                  orient='horizontal', length=200).grid(row=0, column=1, columnspan=2)

        self.steer_var = tk.DoubleVar(value=0.6)
        ttk.Label(drive, text='Steer rate (rad/s)').grid(row=1, column=0, sticky='w')
        ttk.Scale(drive, from_=0.1, to=1.5, variable=self.steer_var,
                  orient='horizontal', length=200).grid(row=1, column=1, columnspan=2)

        b = dict(width=9)
        self.btn(drive, 'Fwd-Left', 2, 0, lambda: self.drive(1, 1), **b)
        self.btn(drive, 'Forward',  2, 1, lambda: self.drive(1, 0), **b)
        self.btn(drive, 'Fwd-Right', 2, 2, lambda: self.drive(1, -1), **b)
        self.btn(drive, 'STOP',     3, 1, lambda: self.drive(0, 0), **b)
        self.btn(drive, 'Rev-Left', 4, 0, lambda: self.drive(-1, -1), **b)
        self.btn(drive, 'Reverse',  4, 1, lambda: self.drive(-1, 0), **b)
        self.btn(drive, 'Rev-Right', 4, 2, lambda: self.drive(-1, 1), **b)

        self.drive_lbl = ttk.Label(drive, text='cmd: 0.00 m/s, 0.00 rad/s')
        self.drive_lbl.grid(row=5, column=0, columnspan=3, sticky='w')

        # keyboard bindings (press = go, release = keep going; Space stops)
        for k in ('w', 'Up'):
            self.root.bind(f'<KeyPress-{k}>', lambda e: self.drive(1, 0))
        for k in ('s', 'Down'):
            self.root.bind(f'<KeyPress-{k}>', lambda e: self.drive(-1, 0))
        for k in ('a', 'Left'):
            self.root.bind(f'<KeyPress-{k}>', lambda e: self.nudge_steer(+1))
        for k in ('d', 'Right'):
            self.root.bind(f'<KeyPress-{k}>', lambda e: self.nudge_steer(-1))
        self.root.bind('<KeyPress-space>', lambda e: self.drive(0, 0))

        # ================= DRILL =================
        drill = ttk.LabelFrame(self.root, text='Drill linear actuator (m extension)')
        drill.pack(fill='x', **pad)
        self.drill_var = tk.DoubleVar(value=0.0)
        s = ttk.Scale(drill, from_=0.0, to=0.24, variable=self.drill_var,
                      orient='horizontal', length=300,
                      command=lambda v: self.on_drill())
        s.grid(row=0, column=0, columnspan=3, padx=6)
        self.drill_lbl = ttk.Label(drill, text='0.000 m')
        self.drill_lbl.grid(row=0, column=3)
        self.btn(drill, 'Retract (0)', 1, 0, lambda: self.set_drill(0.0))
        self.btn(drill, 'Touch ground', 1, 1, lambda: self.set_drill(0.217))
        self.btn(drill, 'Full (0.24)', 1, 2, lambda: self.set_drill(0.24))

        # ================= LEVELER =================
        plow = ttk.LabelFrame(self.root, text='Soil leveler (rad: -0.6 ground .. +0.4 high)')
        plow.pack(fill='x', **pad)
        self.plow_var = tk.DoubleVar(value=0.0)
        ttk.Scale(plow, from_=-0.6, to=0.4, variable=self.plow_var,
                  orient='horizontal', length=300,
                  command=lambda v: self.on_plow()).grid(row=0, column=0, columnspan=3, padx=6)
        self.plow_lbl = ttk.Label(plow, text='0.00 rad')
        self.plow_lbl.grid(row=0, column=3)
        self.btn(plow, 'Ground (-0.6)', 1, 0, lambda: self.set_plow(-0.6))
        self.btn(plow, 'Default (0)', 1, 1, lambda: self.set_plow(0.0))
        self.btn(plow, 'High (+0.4)', 1, 2, lambda: self.set_plow(0.4))

        # ================= GIMBAL / LASER =================
        gim = ttk.LabelFrame(self.root, text='Laser gimbal')
        gim.pack(fill='x', **pad)
        ttk.Label(gim, text='Pan (rad)').grid(row=0, column=0, sticky='w')
        self.pan_var = tk.DoubleVar(value=0.0)
        ttk.Scale(gim, from_=-3.14, to=3.14, variable=self.pan_var,
                  orient='horizontal', length=280,
                  command=lambda v: self.on_pan()).grid(row=0, column=1)
        self.pan_lbl = ttk.Label(gim, text='0.00')
        self.pan_lbl.grid(row=0, column=2)

        ttk.Label(gim, text='Tilt (rad)').grid(row=1, column=0, sticky='w')
        self.tilt_var = tk.DoubleVar(value=0.0)
        ttk.Scale(gim, from_=-0.78, to=0.78, variable=self.tilt_var,
                  orient='horizontal', length=280,
                  command=lambda v: self.on_tilt()).grid(row=1, column=1)
        self.tilt_lbl = ttk.Label(gim, text='0.00')
        self.tilt_lbl.grid(row=1, column=2)

        self.btn(gim, 'Center laser', 2, 1, self.center_gimbal)

        ttk.Label(self.root, foreground='gray',
                  text='Click inside the window for keyboard driving.').pack()

        self.root.protocol('WM_DELETE_WINDOW', self.close)

    # ---------- helpers ----------
    def btn(self, parent, text, r, c, cmd, **kw):
        ttk.Button(parent, text=text, command=cmd, **kw).grid(
            row=r, column=c, padx=3, pady=3)

    def drive(self, f, s):
        self.ros.lin = f * self.speed_var.get()
        self.ros.ang = s * self.steer_var.get() * (1 if f >= 0 else 1)
        if f == 0:
            self.ros.ang = 0.0
        self.update_drive_lbl()

    def nudge_steer(self, direction):
        self.ros.ang = direction * self.steer_var.get()
        if self.ros.lin == 0.0:
            self.ros.lin = self.speed_var.get()  # Ackermann: must roll to steer
        self.update_drive_lbl()

    def update_drive_lbl(self):
        self.drive_lbl.config(
            text=f'cmd: {self.ros.lin:+.2f} m/s, {self.ros.ang:+.2f} rad/s')

    def on_drill(self):
        v = self.drill_var.get()
        self.drill_lbl.config(text=f'{v:.3f} m')
        self.ros.send(self.ros.drill_pub, v)

    def set_drill(self, v):
        self.drill_var.set(v)
        self.on_drill()

    def on_plow(self):
        v = self.plow_var.get()
        self.plow_lbl.config(text=f'{v:+.2f} rad')
        self.ros.send(self.ros.plow_pub, v)

    def set_plow(self, v):
        self.plow_var.set(v)
        self.on_plow()

    def on_pan(self):
        v = self.pan_var.get()
        self.pan_lbl.config(text=f'{v:+.2f}')
        self.ros.send(self.ros.pan_pub, v)

    def on_tilt(self):
        v = self.tilt_var.get()
        self.tilt_lbl.config(text=f'{v:+.2f}')
        self.ros.send(self.ros.tilt_pub, v)

    def center_gimbal(self):
        self.pan_var.set(0.0)
        self.tilt_var.set(0.0)
        self.on_pan()
        self.on_tilt()

    def close(self):
        self.drive(0, 0)
        self.root.destroy()

    def run(self):
        self.root.mainloop()


def main():
    rclpy.init()
    ros = RosBackend()
    spin_thread = threading.Thread(target=rclpy.spin, args=(ros,), daemon=True)
    spin_thread.start()

    gui = ControlPanel(ros)
    try:
        gui.run()
    finally:
        ros.lin = 0.0
        ros.ang = 0.0
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
