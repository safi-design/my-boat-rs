#!/usr/bin/env python3
"""Reactive auto-explorer for an Ackermann robot.

Wanders the environment using /scan for obstacle avoidance so that
slam_toolbox can build the map without manual driving.

Behavior state machine:
  FORWARD  - cruise, steering gently toward the most open direction,
             with occasional random heading changes
  AVOID    - obstacle ahead: arc-turn away from the nearer side
  REVERSE  - too close / boxed in: back up while counter-steering,
             then resume

Ackermann-aware: never commands rotation without linear velocity.

Stop it any time with Ctrl+C (publishes a zero cmd_vel on shutdown).
"""
import math
import random

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan


CRUISE_SPEED = 0.5        # m/s
AVOID_SPEED = 0.3
REVERSE_SPEED = -0.3
TURN_RATE = 0.6           # rad/s commanded during avoidance arcs
FRONT_STOP_DIST = 1.0     # start avoiding below this (m)
FRONT_PANIC_DIST = 0.55   # reverse below this (m)
REVERSE_TIME = 2.5        # s
WANDER_PERIOD = (4.0, 9.0)  # s between random heading nudges


class AutoExplore(Node):
    def __init__(self):
        super().__init__('auto_explore')
        # use_sim_time is auto-declared in Jazzy; set it instead of declaring
        from rclpy.parameter import Parameter
        self.set_parameters([Parameter('use_sim_time', Parameter.Type.BOOL, True)])

        qos = QoSProfile(depth=5, reliability=ReliabilityPolicy.BEST_EFFORT)
        self.scan_sub = self.create_subscription(LaserScan, '/scan',
                                                 self.on_scan, qos)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.timer = self.create_timer(0.1, self.tick)

        self.state = 'FORWARD'
        self.state_until = 0.0
        self.avoid_dir = 1.0
        self.wander_steer = 0.0
        self.next_wander = self.now() + random.uniform(*WANDER_PERIOD)

        self.front = float('inf')
        self.left = float('inf')
        self.right = float('inf')
        self.have_scan = False

        self.get_logger().info('Auto-explore started. Ctrl+C to stop.')

    def now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    # ---------- perception ----------
    def on_scan(self, msg: LaserScan):
        n = len(msg.ranges)
        if n == 0:
            return

        def sector_min(lo_frac, hi_frac):
            lo, hi = int(n * lo_frac), int(n * hi_frac)
            vals = [r for r in msg.ranges[lo:hi]
                    if msg.range_min < r < msg.range_max and math.isfinite(r)]
            return min(vals) if vals else float('inf')

        # camera scan spans ~72 deg total; thirds = right / center / left
        self.right = sector_min(0.00, 0.33)
        self.front = sector_min(0.33, 0.67)
        self.left = sector_min(0.67, 1.00)
        self.have_scan = True

    # ---------- behavior ----------
    def tick(self):
        cmd = Twist()
        t = self.now()

        if not self.have_scan:
            # no scan yet: creep forward slowly so the camera finds a wall
            cmd.linear.x = 0.15
            self.cmd_pub.publish(cmd)
            return

        if self.state == 'REVERSE':
            if t < self.state_until:
                cmd.linear.x = REVERSE_SPEED
                # counter-steer while reversing (car-like escape)
                cmd.angular.z = -self.avoid_dir * TURN_RATE
            else:
                self.state = 'AVOID'
                self.state_until = t + 2.0
            self.cmd_pub.publish(cmd)
            return

        if self.front < FRONT_PANIC_DIST:
            # boxed in: back out, steering away from the more blocked side
            self.avoid_dir = 1.0 if self.left > self.right else -1.0
            self.state = 'REVERSE'
            self.state_until = t + REVERSE_TIME
            self.get_logger().info('Too close (%.2f m) - reversing' % self.front)
            self.cmd_pub.publish(Twist())  # brief stop before reversing
            return

        if self.front < FRONT_STOP_DIST or self.state == 'AVOID':
            if self.state != 'AVOID':
                self.avoid_dir = 1.0 if self.left > self.right else -1.0
                self.state = 'AVOID'
                self.state_until = t + 2.0
            cmd.linear.x = AVOID_SPEED
            cmd.angular.z = self.avoid_dir * TURN_RATE
            # leave AVOID when the way ahead is clear again
            if self.front > FRONT_STOP_DIST * 1.4 and t > self.state_until:
                self.state = 'FORWARD'
            self.cmd_pub.publish(cmd)
            return

        # FORWARD: cruise + gentle bias toward open space + random wander
        if t > self.next_wander:
            self.wander_steer = random.uniform(-0.35, 0.35)
            self.next_wander = t + random.uniform(*WANDER_PERIOD)

        openness_bias = 0.0
        if math.isfinite(self.left) and math.isfinite(self.right):
            openness_bias = 0.15 * math.tanh((self.left - self.right) / 2.0)

        cmd.linear.x = CRUISE_SPEED
        cmd.angular.z = self.wander_steer + openness_bias
        self.cmd_pub.publish(cmd)

    def stop(self):
        self.cmd_pub.publish(Twist())


def main():
    rclpy.init()
    node = AutoExplore()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
